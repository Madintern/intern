# Final-Year-Block-chain-Project


### Nutshell: 
Security of Communication Increase through Use of Combination of Cryptography and Blockchain technology.

### Abstract :

The blockchain is an innovative technology that overcomes these threats and allows decentralisation of sensitive operations while preserving a high level of security. It eliminates the need for trusted intermediaries. The blockchain is accessible to all network nodes and keeps track of all transactions already made. The goal of our work is to propose a secure messaging solution based on blockchain technology. In this project, we explain why blockchain would make communications more secure, and we propose a model design for blockchain-based messaging main- taining the performance and security of data recorded on the blockchain. The system is Combination of blockchain and cryptography process for communication system. 

Final Year Blockchain Project

![Cryptographyand Blockchain Combination PrOJECT](https://user-images.githubusercontent.com/28294942/135728332-aeb851dd-e08e-4179-b664-96de6ce73733.png)


Updates:


https://github.com/Vatshayan/Blockchain-and-Cryptography-Communication-System/blob/main/Untitled%20Diagram.jpg


### Youtube Presentation of this Project : https://youtu.be/Kt8NHdWnvdk


### Contact for this Project files as PPT, Research papers, Code, Report and Video Explanation HD.

### Need Code, Documents & Explanation video ? 

## How to Reach me :

### Mail : vatshayan007@gmail.com 

### WhatsApp: **+91 9310631437** (Helping 24*7) **[CHAT](https://wa.me/message/CHWN2AHCPMAZK1)** 

### Website : https://www.finalproject.in/

### 1000 Computer Science Projects : https://www.computer-science-project.in/

Mail/Message me for Projects Help 🙏🏻

Project is made by **me([Vatshayan](https://github.com/Vatshayan))**
